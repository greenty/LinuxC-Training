#!/bin/bash
for LO in A B C
do
  echo $LO						#输出变量LO的值
done
