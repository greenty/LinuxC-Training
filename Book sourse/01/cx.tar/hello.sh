#!/bin/bash
# 输出Hello World
str="Hello World"
echo $str
