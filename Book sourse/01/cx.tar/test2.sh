$ cat test.sh
#!/bin/bash
echo '当前目录是：`pwd`'
echo 'c*.?'
